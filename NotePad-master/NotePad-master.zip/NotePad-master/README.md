# NotePad
This is an AndroidStudio rebuild of google SDK sample NotePad
